import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  modelReport: any[] = [];
  pieData: any = { labels: [], support: [] };
  pieChart: any;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.updateModelTable();
    this.renderPieChart();
    setInterval(() => this.updateModelTable(), 5000);
    setInterval(() => this.renderPieChart(), 5000);
  }

  updateModelTable() {
    this.http.get<any>('/api/model_report').subscribe(data => {
      this.modelReport = data.table;
      this.pieData = data.pie;
    });
  }

  renderPieChart() {
    const ctx: any = document.getElementById('monitorChart');
    if (this.pieChart) this.pieChart.destroy();
    this.pieChart = new Chart(ctx, {
      type: 'pie',
      data: {
        labels: this.pieData.labels,
        datasets: [{
          data: this.pieData.support,
          backgroundColor: ['#4285F4AA', '#34A853AA', '#FBBC05AA'],
          borderColor: ['#4285F4', '#34A853', '#FBBC05'],
          borderWidth: 1
        }]
      },
      options: {
        plugins: { legend: { display: true, position: 'bottom' } },
        animation: { duration: 800 }
      }
    });
  }

  retrainModel() {
    // Call backend for retrain
  }
}
