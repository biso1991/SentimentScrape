import { Component } from '@angular/core';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.scss']
})
export class AlertComponent {
  status: string = 'success'; // Try 'danger', 'info', etc.
  message: string = 'Ceci est un message de test pour l’alerte !';
  tweets: string = '';
}
