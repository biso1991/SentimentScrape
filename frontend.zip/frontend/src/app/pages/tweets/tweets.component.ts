import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-tweets',
  templateUrl: './tweets.component.html',
  styleUrls: ['./tweets.component.scss']
})
export class TweetsComponent {
  hashtag: string = '';
  tweets: any[] = [];

  constructor(private http: HttpClient) {}

  searchTweets() {
    if (!this.hashtag) return;
    this.http.get<any[]>(`http://localhost:8000/api/tweets?hashtag=${encodeURIComponent(this.hashtag)}`)
      .subscribe({
        next: data => this.tweets = data,
        error: err => {
          this.tweets = [];
        }
      });
  }

  hashtagIcon(text: string): string {
    // Replace hashtags with a colored icon (FontAwesome or Unicode)
    return text.replace(/#(\w+)/g, '<span class="fa fa-hashtag"></span>#$1');
  }
}
