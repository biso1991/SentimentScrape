import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-training',
  templateUrl: './training.component.html',
  styleUrls: ['./training.component.css']
})
export class TrainingComponent {
  models: any[] = []; // Load from API
  uploadProgress: number = 0;
  spinnerVisible = false;

  constructor(private http: HttpClient) {}

  onFileUpload(event: any) {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('model_file', file);

    this.http.post('/upload-model', formData, {
      reportProgress: true,
      observe: 'events'
    }).subscribe(event => {
      if (event.type === 1 && event.total) {
        this.uploadProgress = Math.round(100 * event.loaded / event.total);
      }
    });
  }

  onModelLinkSubmit(modelName: string) {
    this.spinnerVisible = true;
    this.http.post('/link-model', { hf_model_link: modelName }).subscribe(() => {
      this.spinnerVisible = false;
    });
  }
}
